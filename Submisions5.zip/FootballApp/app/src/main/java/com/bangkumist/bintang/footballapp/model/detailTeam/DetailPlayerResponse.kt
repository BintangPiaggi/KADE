package com.bangkumist.bintang.footballapp.model.detailTeam

data class DetailPlayerResponse(
    val players: List<DetailPlayerItems>?
)