package com.bangkumist.bintang.footballapp.model.detailTeam

data class DetailTeamResponse(
    val teams: List<DetailTeamItems>?
)