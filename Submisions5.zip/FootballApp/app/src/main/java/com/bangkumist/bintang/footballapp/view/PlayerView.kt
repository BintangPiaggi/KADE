package com.bangkumist.bintang.footballapp.view

import com.bangkumist.bintang.footballapp.model.detailTeam.PlayerItems

interface PlayerView {
    fun showPlayer(data: List<PlayerItems>)

}