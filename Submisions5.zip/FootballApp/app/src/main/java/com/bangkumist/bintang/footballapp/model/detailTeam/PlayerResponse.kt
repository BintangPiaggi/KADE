package com.bangkumist.bintang.footballapp.model.detailTeam

data class PlayerResponse(
    val player: List<PlayerItems>?
)