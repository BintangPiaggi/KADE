package com.bangkumist.bintang.footballapp.model.detailLeague

data class StandingsResponse(
    val table: List<StandingsItems>?
)