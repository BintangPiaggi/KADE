package com.bangkumist.bintang.footballapp.model

data class DetailLeagueResponse(
    val leagues: List<DetailLeagueItems>
)