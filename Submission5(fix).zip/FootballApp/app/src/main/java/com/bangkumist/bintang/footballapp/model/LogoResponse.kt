package com.bangkumist.bintang.footballapp.model

data class LogoResponse(val teams: List<Logo>)