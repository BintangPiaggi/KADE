package com.bangkumist.bintang.footballapp.model

data class MatchResponse(
    val events: List<MatchItems>?
)
