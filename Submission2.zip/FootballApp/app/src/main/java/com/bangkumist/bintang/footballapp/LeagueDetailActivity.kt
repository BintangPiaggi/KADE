package com.bangkumist.bintang.footballapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.bangkumist.bintang.footballapp.api.ApiRepository
import com.bangkumist.bintang.footballapp.model.DetailLeagueItems
import com.bangkumist.bintang.footballapp.presenter.DetailLeaguePresenter
import com.bangkumist.bintang.footballapp.view.DetailLeagueView
import com.google.gson.Gson
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_league_detail.*
import kotlinx.android.synthetic.main.league_items.*

class LeagueDetailActivity : AppCompatActivity(), DetailLeagueView {


    private lateinit var prenseter: DetailLeaguePresenter

    private lateinit var idLeague : String
    private var nameLeague : String? = null
    private var logoLeague : String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_league_detail)
        val intent = intent
        idLeague = intent.getStringExtra("id_league")
        nameLeague = intent.getStringExtra("name_league")
        logoLeague = intent.getStringExtra("logo_league")

        tvDetailNameLeague.text = nameLeague
        Picasso.get().load(logoLeague).into(imgDetailLeague)

        val request = ApiRepository()
        val gson = Gson()
        prenseter = DetailLeaguePresenter(this, request, gson)
        prenseter.getDetailLeague(idLeague)

    }
    override fun showDetailLeague(data: List<DetailLeagueItems>) {
        tvDetailFormedLeague.text = data.get(0).mFormedLeagueDetail
        tvDescDetailLeague.text  = data.get(0).mDescLeagueDetail
    }
}
