package com.bangkumist.bintang.footballapp.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class MatchItems (
    @SerializedName("idEvent")
    var mIdMatch: String? = null,

    @SerializedName("strHomeTeam")
    var mHomeMatch: String? = null,

    @SerializedName("strAwayTeam")
    var mAwayMatch: String? = null,

    @SerializedName("dateEvent")
    var mDateMatch: String? = null,

    @SerializedName("strTime")
    var mTimeMatch: String? = null,

    @SerializedName("intHomeScore")
    var mHomeScore: String? = null,

    @SerializedName("intAwayScore")
    var mAwayScore: String? = null
): Parcelable