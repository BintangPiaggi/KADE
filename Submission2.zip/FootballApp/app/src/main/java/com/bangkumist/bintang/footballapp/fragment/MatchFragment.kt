package com.bangkumist.bintang.footballapp.fragment


import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.view.*

import com.bangkumist.bintang.footballapp.R
import com.bangkumist.bintang.footballapp.SearchMatchActivity
import com.bangkumist.bintang.footballapp.adapter.ViewPagerAdapter
import com.bangkumist.bintang.footballapp.matchfragment.NextFragment
import com.bangkumist.bintang.footballapp.matchfragment.PrevFragment
import org.jetbrains.anko.support.v4.startActivity

class MatchFragment : Fragment() {
    private lateinit var viewPagerr: ViewPager
    private lateinit var tabss: TabLayout

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view: View = inflater.inflate(R.layout.fragment_match, container, false)

        viewPagerr = view.findViewById(R.id.viewpager)
        tabss = view.findViewById(R.id.tabb)
        setHasOptionsMenu(true)
        setupViewPager(viewPagerr)

        return view
    }

    private fun setupViewPager(viewPager: ViewPager) {
        val adapter = ViewPagerAdapter(childFragmentManager)
        adapter.populateFragment(PrevFragment(), "Previous Match")
        adapter.populateFragment(NextFragment(), "Next Match")
        viewPager.adapter = adapter
        tabss.setupWithViewPager(viewPagerr)
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        menu?.clear()
        inflater?.inflate(R.menu.main_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }
    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        return when (item?.itemId) {
            R.id.searchId -> {
                startActivity<SearchMatchActivity>()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
