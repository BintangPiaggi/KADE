package com.bangkumist.bintang.footballapp.model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
class DetailMatchItems (

    @SerializedName("strHomeTeam")
    var mHomeDetailMatch: String? = null,

    @SerializedName("strAwayTeam")
    var mAwayDetailMatch: String? = null,

    @SerializedName("intHomeScore")
    var mHomeDetailScore: String? = null,

    @SerializedName("intAwayScore")
    var mAwayDetailScore: String? = null,

    @SerializedName("strHomeGoalDetails")
    val mHomeGoal: String? = null,

    @SerializedName("strAwayGoalDetails")
    val mAwayGoal: String? = null,

    @SerializedName("intHomeShots")
    val mHomeShots: String? = null,

    @SerializedName("intAwayShots")
    val mAwayShots: String? = null,

    @SerializedName("strHomeLineupGoalkeeper")
    val mHomeGK: String? = null,

    @SerializedName("strAwayLineupGoalkeeper")
    val mAwayGk: String? = null,

    @SerializedName("strHomeLineupDefense")
    val mHomeDef: String? = null,

    @SerializedName("strAwayLineupDefense")
    val mAwayDef: String? = null,

    @SerializedName("strHomeLineupMidfield")
    val mHomeMid: String? = null,

    @SerializedName("strAwayLineupMidfield")
    val mAwayMid: String? = null,

    @SerializedName("strHomeLineupForward")
    val mHomeFw: String? = null,

    @SerializedName("strAwayLineupForward")
    val mAwayFw: String? = null,

    @SerializedName("strHomeLineupSubstitutes")
    val mHomeSub: String? = null,

    @SerializedName("strAwayLineupSubstitutes")
    val mAwaySub: String? = null,
    @SerializedName("strHomeYellowCards")
    var mHomeYellow: String? = null,

    @SerializedName("strAwayYellowCards")
    var mAwayYellow: String? = null
):Parcelable