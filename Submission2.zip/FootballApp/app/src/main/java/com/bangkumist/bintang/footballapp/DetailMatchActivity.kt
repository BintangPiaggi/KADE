package com.bangkumist.bintang.footballapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.bangkumist.bintang.footballapp.api.ApiRepository
import com.bangkumist.bintang.footballapp.model.DetailMatchItems
import com.bangkumist.bintang.footballapp.presenter.DetailMatchPresenter
import com.bangkumist.bintang.footballapp.view.DetailMatchView
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_detail_match.*

class DetailMatchActivity : AppCompatActivity(), DetailMatchView {



    private lateinit var prenseter: DetailMatchPresenter

    private lateinit var idLeague : String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_match)
        val intent = intent
        idLeague = intent.getStringExtra("id_match")

        val request = ApiRepository()
        val gson = Gson()
        prenseter = DetailMatchPresenter(this, request, gson)
        prenseter.getDetailMatch(idLeague)

    }
    override fun showDetailLeague(data: List<DetailMatchItems>) {
        tvHome.text = data.get(0).mHomeDetailMatch
        tvRAway.text = data.get(0).mAwayDetailMatch
        tvHomeScore.text = data.get(0).mHomeDetailScore
        tvAwayScore.text = data.get(0).mAwayDetailScore
        tvGoalHome.text = data.get(0).mHomeGoal
        tvGoalAway.text = data.get(0).mAwayGoal
        tvDefHome.text = data.get(0).mHomeDef
        tvDefAway.text = data.get(0).mAwayDef
        tvFwHome.text = data.get(0).mHomeFw
        tvFwAway.text = data.get(0).mAwayFw
        tvGKHome.text = data.get(0).mHomeGK
        tvGKAway.text = data.get(0).mAwayGk
        tvMidHome.text = data.get(0).mHomeMid
        tvMidAway.text = data.get(0).mAwayMid
        tvSubHome.text = data.get(0).mHomeSub
        tvSubAway.text = data.get(0).mAwaySub
        tvYellowHome.text = data.get(0).mHomeYellow
        tvYellowAway.text = data.get(0).mAwayYellow
    }
}
