package com.bangkumist.bintang.footballapp.view

import com.bangkumist.bintang.footballapp.model.DetailMatchItems

interface DetailMatchView {
    fun showDetailLeague(data: List<DetailMatchItems>)
}