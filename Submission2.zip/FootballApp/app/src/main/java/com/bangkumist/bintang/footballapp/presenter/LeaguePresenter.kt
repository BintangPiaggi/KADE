package com.bangkumist.bintang.footballapp.presenter

import com.bangkumist.bintang.footballapp.api.ApiRepository
import com.bangkumist.bintang.footballapp.api.TheSportDBApi
import com.bangkumist.bintang.footballapp.fragment.LeagueFragment
import com.bangkumist.bintang.footballapp.model.LeagueResponse
import com.bangkumist.bintang.footballapp.view.LeagueView
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class LeaguePresenter(private val view: LeagueView,
                      private val apiRepository: ApiRepository,
                      private val gson: Gson) {
    fun getLeagueList(league: String?) {
        view.showLoading()
        doAsync {
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getLeague(league)),
                LeagueResponse::class.java
            )

            uiThread {
                view.hideLoading()
                view.showLeague(data.countrys)
            }
        }
    }
}