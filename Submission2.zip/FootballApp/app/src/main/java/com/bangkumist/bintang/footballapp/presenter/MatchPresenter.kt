package com.bangkumist.bintang.footballapp.presenter

import com.bangkumist.bintang.footballapp.api.ApiRepository
import com.bangkumist.bintang.footballapp.api.TheSportDBApi
import com.bangkumist.bintang.footballapp.model.MatchResponse
import com.bangkumist.bintang.footballapp.view.MatchView
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class MatchPresenter(private val view: MatchView,
                     private val apiRepository: ApiRepository,
                     private val gson: Gson) {
    fun getPrevMatch(league: String?) {
        doAsync {
            view.showLoading()
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getPrevMatch(league)),
                MatchResponse::class.java
            )
            uiThread {
                view.hideLoading()
                view.showMatch(data.events)
            }
        }
    }
    fun getNextMatch(league: String?) {
        doAsync {
            view.showLoading()
            val data = gson.fromJson(apiRepository
                .doRequest(TheSportDBApi.getNextMatch(league)),
                MatchResponse::class.java
            )
            uiThread {
                view.hideLoading()
                view.showMatch(data.events)
            }
        }
    }
}