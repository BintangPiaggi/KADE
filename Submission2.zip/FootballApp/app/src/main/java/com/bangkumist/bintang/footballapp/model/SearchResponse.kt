package com.bangkumist.bintang.footballapp.model

data class SearchResponse (
    val event: List<MatchItems>
)