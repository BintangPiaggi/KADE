package com.bangkumist.bintang.footballapp.view

import com.bangkumist.bintang.footballapp.model.DetailLeagueItems

interface DetailLeagueView {
    fun showDetailLeague(data: List<DetailLeagueItems>)
}