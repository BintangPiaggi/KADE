package com.bangkumist.bintang.footballapp.model

data class DetailMatchResponse(
    val events: List<MatchItems>
)