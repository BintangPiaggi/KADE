package com.bangkumist.bintang.footballapp.model.detailLeague

data class TeamResponse(
    val teams: List<TeamItems>?
)