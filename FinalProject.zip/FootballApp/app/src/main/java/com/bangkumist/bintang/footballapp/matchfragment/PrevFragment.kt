package com.bangkumist.bintang.footballapp.matchfragment


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.widget.SwipeRefreshLayout
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.Spinner
import com.bangkumist.bintang.footballapp.activity.DetailMatchActivity

import com.bangkumist.bintang.footballapp.R
import com.bangkumist.bintang.footballapp.adapter.MatchAdapter
import com.bangkumist.bintang.footballapp.api.ApiRepository
import com.bangkumist.bintang.footballapp.model.MatchItems
import com.bangkumist.bintang.footballapp.presenter.MatchPresenter
import com.bangkumist.bintang.footballapp.utils.invisible
import com.bangkumist.bintang.footballapp.utils.visible
import com.bangkumist.bintang.footballapp.view.MatchView
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_prev.view.*
import org.jetbrains.anko.support.v4.onRefresh
import org.jetbrains.anko.support.v4.startActivity

class PrevFragment : Fragment(), MatchView {


    private var event: MutableList<MatchItems> = mutableListOf()
    private lateinit var presenter: MatchPresenter
    private lateinit var adapter: MatchAdapter
    private lateinit var idLeague: String
    private lateinit var sp: Spinner
    private lateinit var pb: ProgressBar
    private lateinit var sr: SwipeRefreshLayout

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_prev, container, false)
        val rv = view.findViewById<RecyclerView>(R.id.rcPrevMatch)
        pb = view.pb_PrevMatch
        sr = view.sr_prevmatch
        adapter = MatchAdapter(event) {
            onClickItem(it)
        }
        rv.adapter = adapter
        rv.layoutManager = LinearLayoutManager(context)

        val request = ApiRepository()
        val gson = Gson()
        presenter = MatchPresenter(this, request, gson)


        val leagueId = resources.getStringArray(R.array.league_id)
        val spinnerItems = resources.getStringArray(R.array.league_name)
        val spinnerAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, spinnerItems)
        sp = view.sp_prevmatch
        sp.adapter = spinnerAdapter
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                idLeague = leagueId[position].toString()
                presenter.getPrevMatch(idLeague)
            }

        }
        sr.onRefresh {
            presenter.getPrevMatch(idLeague)
        }
        return view
    }

    override fun showLoading() {
        pb.visible()

    }

    override fun hideLoading() {
        pb.invisible()
    }

    override fun showMatch(data: List<MatchItems>) {
        sr.isRefreshing = false
        event.clear()
        event.addAll(data)
        adapter.notifyDataSetChanged()
    }

    private fun onClickItem(items: MatchItems) {
        startActivity<DetailMatchActivity>(
            "id" to items.mIdMatch,
        "home" to items.mHomeMatch,
        "away" to items.mAwayMatch,
        "homeScore" to items.mHomeScore,
        "awayScore" to  items.mAwayScore)
    }
}
