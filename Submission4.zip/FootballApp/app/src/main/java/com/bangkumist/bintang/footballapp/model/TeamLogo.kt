package com.bangkumist.bintang.footballapp.model

import com.google.gson.annotations.SerializedName

data class TeamLogo (
    @SerializedName("strTeamBadge")
    val mBadge: String? = ""
)