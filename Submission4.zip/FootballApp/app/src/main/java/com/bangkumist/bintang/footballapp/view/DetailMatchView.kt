package com.bangkumist.bintang.footballapp.view

import com.bangkumist.bintang.footballapp.model.MatchItems
import com.bangkumist.bintang.footballapp.model.TeamLogo

interface DetailMatchView {
    fun showDetailLeague(data: List<MatchItems>)

    fun showHomeTeamLogo (data: List<TeamLogo>)

    fun showAwayTeamLogo (data: List<TeamLogo>)
}