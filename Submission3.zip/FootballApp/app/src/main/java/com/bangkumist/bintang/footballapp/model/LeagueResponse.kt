package com.bangkumist.bintang.footballapp.model

data class LeagueResponse(
    val countrys: List<LeagueItems>
)

