package com.bangkumist.bintang.footballapp.view

import com.bangkumist.bintang.footballapp.model.MatchItems

interface DetailMatchView {
    fun showDetailLeague(data: List<MatchItems>)
}