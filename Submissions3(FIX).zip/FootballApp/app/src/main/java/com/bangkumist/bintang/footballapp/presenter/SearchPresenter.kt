package com.bangkumist.bintang.footballapp.presenter

import com.bangkumist.bintang.footballapp.api.ApiRepository
import com.bangkumist.bintang.footballapp.api.TheSportDBApi
import com.bangkumist.bintang.footballapp.model.SearchResponse
import com.bangkumist.bintang.footballapp.view.SearchMatchView
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class SearchPresenter(
    private val view: SearchMatchView,
    private val apiRepository: ApiRepository,
    private val gson: Gson
) {
    fun getSearchMatch(league: String?) {
        doAsync {
            val data = gson.fromJson(
                apiRepository
                    .doRequest(TheSportDBApi.getSearchMatch(league)),
                SearchResponse::class.java
            )
            uiThread {
                data.event?.let { it1 -> view.showMatch(it1) }
            }
        }
    }
}