package com.bangkumist.bintang.footballapp.presenter

import com.bangkumist.bintang.footballapp.api.ApiRepository
import com.bangkumist.bintang.footballapp.api.TheSportDBApi
import com.bangkumist.bintang.footballapp.model.DetailLeagueResponse
import com.bangkumist.bintang.footballapp.view.DetailLeagueView
import com.google.gson.Gson
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread


class DetailLeaguePresenter(
    private val view: DetailLeagueView,
    private val apiRepository: ApiRepository,
    private val gson: Gson
) {
    fun getDetailLeague(league: String?) {
        doAsync {
            val data = gson.fromJson(
                apiRepository
                    .doRequest(TheSportDBApi.getDetailLeague(league)),
                DetailLeagueResponse::class.java
            )

            uiThread {
                view.showDetailLeague(data.leagues)
            }
        }
    }
}