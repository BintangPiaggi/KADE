package com.bangkumist.bintang.footballapp.model

data class TeamLogoResponse( val teams: List<TeamLogo>)